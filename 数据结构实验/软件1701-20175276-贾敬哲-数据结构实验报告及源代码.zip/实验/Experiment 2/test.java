package SPFA;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class test {

    public static void main(String[] args) {
        String a = "123456";
        System.out.println(a.hashCode());
    }
}
