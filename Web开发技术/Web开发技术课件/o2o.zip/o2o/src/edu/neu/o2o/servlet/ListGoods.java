package edu.neu.o2o.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.neu.o2o.bean.Goods;

/**
 * Servlet implementation class ListGoods
 */
@WebServlet("/goods/list")
public class ListGoods extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListGoods() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<Goods> list = new ArrayList<Goods>();
		try {
			// 加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			// 获得数据库链接
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/o2o?useUnicode=true&characterEncoding=UTF-8&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
					"root", "123456");
			// 创建Statement
			Statement s = conn.createStatement();
			// 执行操作
			String sql = "select * from goods";
			ResultSet rs = s.executeQuery(sql);
			while(rs.next()) {
				Goods g = new Goods();
				g.setId(rs.getInt("id"));
				g.setName(rs.getString("name"));
				g.setPrice(rs.getFloat("price"));
				g.setCategory(rs.getString("category"));
				System.out.println(g);
				list.add(g);
			}
			// 关闭连接
			conn.close();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("list", list);
		request.getRequestDispatcher("../jsp/goods/list.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
